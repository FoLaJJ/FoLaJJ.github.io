# 本文件用于训练DGA检测的决策树（Decision Tree）模型
# 输出全部保存在 model/dt/ 目录下

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import classification_report, confusion_matrix
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from tqdm import tqdm
import gc
import psutil
import warnings
import logging
from io import StringIO
import sys
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

class StreamToLogger:
    def __init__(self, logger, level):
        self.logger = logger
        self.level = level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.level, line.rstrip())

    def flush(self):
        pass

class DGADetector:
    def __init__(self, output_dir='model/dt'):
        self.output_dir = output_dir
        self.model = None
        self.feature_importance = None
        
        # 设置日志
        self.setup_logging()
        
    def setup_logging(self):
        """设置日志记录"""
        # 创建日志目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 创建日志文件名（使用时间戳）
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = os.path.join(self.output_dir, f'training_log_{timestamp}.txt')
        
        # 配置日志记录器
        self.logger = logging.getLogger('DGADetector')
        self.logger.setLevel(logging.INFO)
        
        # 文件处理器
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # 设置日志格式
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # 添加处理器
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        # 重定向标准输出和错误输出到日志
        sys.stdout = StreamToLogger(self.logger, logging.INFO)
        sys.stderr = StreamToLogger(self.logger, logging.ERROR)
        
    def print_memory_usage(self):
        """打印当前内存使用情况"""
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        self.logger.info(f"当前内存使用: {memory_info.rss / 1024 / 1024:.2f} MB")
        
    def load_data(self, data_path):
        """加载特征工程后的数据"""
        self.logger.info("正在加载数据...")
        self.print_memory_usage()
        
        # 使用chunksize分批读取数据
        chunk_size = 100000
        chunks = []
        for chunk in tqdm(pd.read_csv(data_path, chunksize=chunk_size), 
                         desc="加载数据"):
            chunks.append(chunk)
            gc.collect()  # 及时清理内存
        
        df = pd.concat(chunks, ignore_index=True)
        self.logger.info(f"数据加载完成，共 {len(df)} 条记录")
        self.print_memory_usage()
        return df
    
    def prepare_data(self, df):
        """准备训练数据"""
        self.logger.info("正在准备训练数据...")
        self.print_memory_usage()
        
        # 检查并处理缺失值
        self.logger.info("检查缺失值...")
        missing_values = df.isnull().sum()
        if missing_values.any():
            self.logger.info("\n发现缺失值:")
            self.logger.info(str(missing_values[missing_values > 0]))
            self.logger.info("\n处理缺失值...")
            # 删除包含缺失值的行
            df = df.dropna()
            self.logger.info(f"删除缺失值后的数据量: {len(df)}")
        
        # 分离特征和标签
        X = df.drop(['label', 'class'], axis=1)
        y = df['class']
        
        # 检查标签中的异常值
        self.logger.info("\n检查标签分布:")
        self.logger.info(str(y.value_counts(normalize=True)))
        
        # 优化数据类型
        self.logger.info("\n优化数据类型...")
        for col in X.columns:
            if X[col].dtype == 'float64':
                X[col] = X[col].astype('float32')
        
        # 划分训练集和验证集
        self.logger.info("\n划分训练集和验证集...")
        X_train, X_val, y_train, y_val = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # 清理内存
        del X, y
        gc.collect()
        
        self.logger.info("数据准备完成")
        self.logger.info(f"训练集大小: {len(X_train)}")
        self.logger.info(f"验证集大小: {len(X_val)}")
        self.print_memory_usage()
        return X_train, X_val, y_train, y_val
    
    def train_model(self, X_train, y_train):
        """训练决策树模型"""
        self.logger.info("正在训练模型...")
        self.print_memory_usage()
        
        self.model = DecisionTreeClassifier(
            max_depth=20,           # 降低树的深度
            min_samples_split=15,   # 增加最小分裂样本数
            min_samples_leaf=8,     # 增加最小叶子节点样本数
            max_features=0.6,       # 降低特征采样比例
            random_state=42,
            class_weight='balanced',
            min_weight_fraction_leaf=0.01,  # 添加最小权重分数
            min_impurity_decrease=0.001,    # 添加最小不纯度减少
            ccp_alpha=0.01,                 # 添加剪枝参数
            splitter='best'                 # 使用最佳分裂器
        )
        
        # 使用tqdm包装训练过程
        with tqdm(total=100, desc="训练进度") as pbar:
            def progress_callback(iteration):
                pbar.update(1)
            self.model.fit(X_train, y_train)
        
        # 获取特征重要性
        self.feature_importance = pd.DataFrame({
            'feature': X_train.columns,
            'importance': self.model.feature_importances_
        }).sort_values('importance', ascending=False)
        
        # 保存特征重要性图
        plt.figure(figsize=(15, 8))
        sns.barplot(x='importance', y='feature', 
                   data=self.feature_importance.head(30))
        plt.title('Top 30 特征重要性')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'feature_importance.png'))
        plt.close()
        
        self.logger.info("模型训练完成")
        self.print_memory_usage()
    
    def evaluate_model(self, X_val, y_val):
        """评估模型性能"""
        self.logger.info("正在评估模型...")
        self.print_memory_usage()
        
        # 分批预测以减少内存使用
        batch_size = 10000
        y_pred = []
        y_pred_proba = []
        
        for i in tqdm(range(0, len(X_val), batch_size), desc="模型评估"):
            batch = X_val.iloc[i:i+batch_size]
            batch_pred = self.model.predict(batch)
            batch_pred_proba = self.model.predict_proba(batch)
            y_pred.extend(batch_pred)
            y_pred_proba.extend(batch_pred_proba[:, 1])  # 获取正类的概率
            gc.collect()
        
        y_pred = np.array(y_pred)
        y_pred_proba = np.array(y_pred_proba)
        
        # 打印分类报告
        self.logger.info("\n分类报告:")
        report = classification_report(y_val, y_pred)
        self.logger.info(report)
        
        # 计算ROC曲线和AUC
        from sklearn.metrics import roc_curve, auc
        fpr, tpr, _ = roc_curve(y_val, y_pred_proba)
        roc_auc = auc(fpr, tpr)
        
        # 绘制ROC曲线
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2, 
                 label=f'ROC curve (AUC = {roc_auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC曲线')
        plt.legend(loc="lower right")
        plt.savefig(os.path.join(self.output_dir, 'roc_curve.png'))
        plt.close()
        
        # 绘制混淆矩阵
        cm = confusion_matrix(y_val, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('混淆矩阵')
        plt.ylabel('真实标签')
        plt.xlabel('预测标签')
        plt.savefig(os.path.join(self.output_dir, 'confusion_matrix.png'))
        plt.close()
        
        # 计算四个核心评估指标
        tn, fp, fn, tp = cm.ravel()
        accuracy = (tp + tn) / (tp + tn + fp + fn)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        self.logger.info("\n模型评估核心指标:")
        self.logger.info(f"准确率 (Accuracy): {accuracy:.4f}")
        self.logger.info(f"精确率 (Precision): {precision:.4f}")
        self.logger.info(f"召回率 (Recall): {recall:.4f}")
        self.logger.info(f"F1-Score: {f1:.4f}")
        
        # 将指标保存到CSV文件
        metrics_df = pd.DataFrame({
            '指标': ['准确率(Accuracy)', '精确率(Precision)', '召回率(Recall)', 'F1-Score'],
            '值': [accuracy, precision, recall, f1]
        })
        metrics_path = os.path.join(self.output_dir, 'model_metrics.csv')
        metrics_df.to_csv(metrics_path, index=False, encoding='utf-8')
        self.logger.info(f"\n评估指标已保存到: {metrics_path}")
        
        self.logger.info("模型评估完成")
        self.print_memory_usage()
    
    def save_model(self):
        """保存模型和相关信息"""
        self.logger.info("正在保存模型...")
        self.print_memory_usage()
        
        # 保存模型
        model_path = os.path.join(self.output_dir, 'dga_detector.joblib')
        joblib.dump(self.model, model_path)
        
        # 保存特征重要性
        importance_path = os.path.join(self.output_dir, 'feature_importance.csv')
        self.feature_importance.to_csv(importance_path, index=False)
        
        # 保存训练信息
        info = {
            'model_type': 'DecisionTreeClassifier',
            'max_depth': self.model.max_depth,
            'min_samples_split': self.model.min_samples_split,
            'min_samples_leaf': self.model.min_samples_leaf,
            'feature_importance': self.feature_importance.to_dict()
        }
        info_path = os.path.join(self.output_dir, 'training_info.joblib')
        joblib.dump(info, info_path)
        
        self.logger.info(f"模型已保存到: {model_path}")
        self.logger.info(f"特征重要性已保存到: {importance_path}")
        self.logger.info(f"训练信息已保存到: {info_path}")
        self.print_memory_usage()

def main():
    # 指定模型名称
    model_name = "dt"
    output_dir = os.path.join(os.path.dirname(__file__), "model", model_name)
    os.makedirs(output_dir, exist_ok=True)
    
    # 初始化检测器
    detector = DGADetector(output_dir)
    
    # 加载总特征数据
    all_data_path = os.path.join(os.path.dirname(__file__), "output", "all_features.csv")
    df = pd.read_csv(all_data_path)
    
    # 划分特征和标签
    X = df.drop(['label', 'class'], axis=1)
    y = df['class']
    
    # 按照7:1:2的比例划分训练集、验证集和测试集
    X_train, temp_df, y_train, temp_y = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
    X_val, X_test, y_val, y_test = train_test_split(temp_df, temp_y, test_size=0.67, random_state=42, stratify=temp_y)
    
    # 训练模型
    detector.train_model(X_train, y_train)
    
    # 评估模型（验证集）
    detector.evaluate_model(X_val, y_val)
    # 评估模型（测试集）
    detector.evaluate_model(X_test, y_test)
    
    # 保存模型
    detector.save_model()
    
    # 清理内存
    del df, X_train, X_val, X_test, y_train, y_val, y_test
    gc.collect()

if __name__ == "__main__":
    main() 