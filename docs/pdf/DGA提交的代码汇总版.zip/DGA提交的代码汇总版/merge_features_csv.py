import pandas as pd
import numpy as np
import os
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

def validate_and_preprocess(df):
    """验证和预处理数据"""
    print("开始数据验证和预处理...")
    
    # 检查缺失值
    missing_values = df.isnull().sum()
    if missing_values.any():
        print("\n发现缺失值:")
        print(missing_values[missing_values > 0])
        # 使用中位数填充数值型特征的缺失值
        numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
        for col in numeric_cols:
            df[col] = df[col].fillna(df[col].median())
    
    # 检查异常值
    numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
    for col in numeric_cols:
        if col not in ['class', 'label']:  # 排除标签列
            Q1 = df[col].quantile(0.25)
            Q3 = df[col].quantile(0.75)
            IQR = Q3 - Q1
            lower_bound = Q1 - 1.5 * IQR
            upper_bound = Q3 + 1.5 * IQR
            df[col] = df[col].clip(lower_bound, upper_bound)
    
    # 标准化数值特征
    scaler = StandardScaler()
    numeric_cols = df.select_dtypes(include=['float64', 'int64']).columns
    numeric_cols = [col for col in numeric_cols if col not in ['class', 'label']]
    df[numeric_cols] = scaler.fit_transform(df[numeric_cols])
    
    return df

def merge_csvs():
    """合并并处理特征文件"""
    print("开始合并特征文件...")
    
    output_dir = os.path.join(os.path.dirname(__file__), 'output')
    train_csv = os.path.join(output_dir, 'train_features.csv')
    val_csv = os.path.join(output_dir, 'validation_features.csv')
    test_csv = os.path.join(output_dir, 'test_features.csv')
    all_csv = os.path.join(output_dir, 'all_features.csv')
    selected_features_csv = os.path.join(output_dir, 'selected_features.csv')
    
    # 读取选择的特征
    selected_features = pd.read_csv(selected_features_csv)['feature_name'].tolist()
    selected_features.extend(['class', 'label'])  # 添加标签列
    
    # 读取数据
    print("读取数据集...")
    df_train = pd.read_csv(train_csv)
    df_val = pd.read_csv(val_csv)
    df_test = pd.read_csv(test_csv)
    
    # 验证数据集大小
    print(f"\n数据集大小:")
    print(f"训练集: {len(df_train)} 样本")
    print(f"验证集: {len(df_val)} 样本")
    print(f"测试集: {len(df_test)} 样本")
    
    # 使用选择的特征
    print("\n使用选择的特征...")
    df_train = df_train[selected_features]
    df_val = df_val[selected_features]
    df_test = df_test[selected_features]
    
    # 合并数据集
    print("\n合并数据集...")
    df_all = pd.concat([df_train, df_val, df_test], ignore_index=True)
    
    # 验证和预处理
    df_all = validate_and_preprocess(df_all)
    
    # 保存合并后的数据
    print("\n保存合并后的数据...")
    df_all.to_csv(all_csv, index=False)
    print(f'已合并所有特征到: {all_csv}')
    
    # 输出数据集统计信息
    print("\n数据集统计信息:")
    print(f"总样本数: {len(df_all)}")
    print("\n类别分布:")
    print(df_all['class'].value_counts(normalize=True))
    
    # 保存数据集统计信息
    stats_file = os.path.join(output_dir, 'dataset_statistics.txt')
    with open(stats_file, 'w', encoding='utf-8') as f:
        f.write("数据集统计信息\n")
        f.write("=" * 50 + "\n\n")
        f.write(f"总样本数: {len(df_all)}\n\n")
        f.write("类别分布:\n")
        f.write(str(df_all['class'].value_counts(normalize=True)))
        f.write("\n\n特征统计:\n")
        f.write(str(df_all.describe()))
    
    print(f"\n数据集统计信息已保存到: {stats_file}")

if __name__ == '__main__':
    merge_csvs() 