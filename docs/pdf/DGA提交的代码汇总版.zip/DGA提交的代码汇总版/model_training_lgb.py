# 本文件用于训练DGA检测的LightGBM模型
# 输出全部保存在 model/lgb/ 目录下

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
import lightgbm as lgb
from sklearn.metrics import classification_report, confusion_matrix
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from tqdm import tqdm
import gc
import psutil
import warnings
import logging
from io import StringIO
import sys
import tempfile
import shutil
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

class StreamToLogger:
    def __init__(self, logger, level):
        self.logger = logger
        self.level = level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.level, line.rstrip())

    def flush(self):
        pass

class DGADetector:
    def __init__(self, output_dir='model/lgb'):
        self.output_dir = output_dir
        self.model = None
        self.feature_importance = None
        
        # 设置日志
        self.setup_logging()
        
    def setup_logging(self):
        """设置日志记录"""
        # 创建日志目录
        os.makedirs(self.output_dir, exist_ok=True)
        
        # 创建日志文件名（使用时间戳）
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = os.path.join(self.output_dir, f'training_log_{timestamp}.txt')
        
        # 配置日志记录器
        self.logger = logging.getLogger('DGADetector')
        self.logger.setLevel(logging.INFO)
        
        # 文件处理器
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # 设置日志格式
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # 添加处理器
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        # 重定向标准输出和错误输出到日志
        sys.stdout = StreamToLogger(self.logger, logging.INFO)
        sys.stderr = StreamToLogger(self.logger, logging.ERROR)
        
    def print_memory_usage(self):
        """打印当前内存使用情况"""
        process = psutil.Process(os.getpid())
        memory_info = process.memory_info()
        self.logger.info(f"当前内存使用: {memory_info.rss / 1024 / 1024:.2f} MB")
        
    def load_data(self, train_path, val_path, test_path):
        """加载特征工程后的数据"""
        self.logger.info("正在加载数据...")
        self.print_memory_usage()
        
        # 使用chunksize分批读取数据
        chunk_size = 100000
        train_chunks = []
        val_chunks = []
        test_chunks = []
        
        # 加载训练集
        self.logger.info("加载训练集...")
        for chunk in tqdm(pd.read_csv(train_path, chunksize=chunk_size), 
                         desc="加载训练集"):
            train_chunks.append(chunk)
            gc.collect()
        
        # 加载验证集
        self.logger.info("加载验证集...")
        for chunk in tqdm(pd.read_csv(val_path, chunksize=chunk_size), 
                         desc="加载验证集"):
            val_chunks.append(chunk)
            gc.collect()
            
        # 加载测试集
        self.logger.info("加载测试集...")
        for chunk in tqdm(pd.read_csv(test_path, chunksize=chunk_size), 
                         desc="加载测试集"):
            test_chunks.append(chunk)
            gc.collect()
        
        # 合并数据块
        train_df = pd.concat(train_chunks, ignore_index=True)
        val_df = pd.concat(val_chunks, ignore_index=True)
        test_df = pd.concat(test_chunks, ignore_index=True)
        
        self.logger.info(f"数据加载完成:")
        self.logger.info(f"训练集大小: {len(train_df)}")
        self.logger.info(f"验证集大小: {len(val_df)}")
        self.logger.info(f"测试集大小: {len(test_df)}")
        self.print_memory_usage()
        
        return train_df, val_df, test_df
    
    def prepare_data(self, train_df, val_df, test_df):
        """准备训练数据"""
        self.logger.info("正在准备训练数据...")
        self.print_memory_usage()
        
        # 处理训练集
        self.logger.info("处理训练集...")
        X_train = train_df.drop(['label', 'class'], axis=1)
        y_train = train_df['class']
        
        # 处理验证集
        self.logger.info("处理验证集...")
        X_val = val_df.drop(['label', 'class'], axis=1)
        y_val = val_df['class']
        
        # 处理测试集
        self.logger.info("处理测试集...")
        X_test = test_df.drop(['label', 'class'], axis=1)
        y_test = test_df['class']
        
        # 检查并处理缺失值
        self.logger.info("检查缺失值...")
        for name, X in [('训练集', X_train), ('验证集', X_val), ('测试集', X_test)]:
            missing_values = X.isnull().sum()
            if missing_values.any():
                self.logger.info(f"\n{name}发现缺失值:")
                self.logger.info(str(missing_values[missing_values > 0]))
                self.logger.info(f"\n处理{name}缺失值...")
                X.fillna(X.mean(), inplace=True)  # 使用均值填充缺失值
        
        # 优化数据类型
        self.logger.info("\n优化数据类型...")
        for X in [X_train, X_val, X_test]:
            for col in X.columns:
                if X[col].dtype == 'float64':
                    X[col] = X[col].astype('float32')
        
        # 检查标签分布
        self.logger.info("\n检查标签分布:")
        for name, y in [('训练集', y_train), ('验证集', y_val), ('测试集', y_test)]:
            self.logger.info(f"\n{name}标签分布:")
            self.logger.info(str(y.value_counts(normalize=True)))
        
        # 自动设置scale_pos_weight
        num_neg = (y_train == 0).sum()
        num_pos = (y_train == 1).sum()
        self.pos_weight = num_neg / num_pos if num_pos > 0 else 1.0
        self.logger.info(f"自动设置 scale_pos_weight: {self.pos_weight:.4f} (负样本/正样本)")
        
        self.logger.info("数据准备完成")
        self.print_memory_usage()
        return X_train, X_val, X_test, y_train, y_val, y_test
    
    def train_model(self, X_train, y_train, X_val, y_val):
        """训练LightGBM模型"""
        self.logger.info("正在训练模型...")
        self.print_memory_usage()
        
        # LightGBM参数设置 - 针对新特征优化
        params = {
            'objective': 'binary',
            'metric': ['auc', 'binary_logloss'],
            'boosting_type': 'gbdt',
            'num_leaves': 63,                # 增加叶子节点数
            'learning_rate': 0.03,           # 降低学习率
            'feature_fraction': 0.7,         # 降低特征采样比例
            'bagging_fraction': 0.7,         # 降低样本采样比例
            'bagging_freq': 5,
            'verbose': -1,
            'max_depth': 15,                 # 降低树的深度
            'num_iterations': 1500,          # 增加迭代次数
            'min_child_samples': 30,         # 增加最小样本数
            'min_child_weight': 0.005,       # 增加最小权重
            'min_split_gain': 0.1,           # 增加最小分裂增益
            'reg_alpha': 0.3,                # 增加L1正则化
            'reg_lambda': 1.5,               # 增加L2正则化
            'scale_pos_weight': self.pos_weight,
            'random_state': 42,
            'drop_rate': 0.1,                # 添加dropout
            'top_rate': 0.3,                 # 添加GOSS
            'other_rate': 0.1,               # 添加GOSS
            'max_drop': 50,                  # 添加dropout
            'skip_drop': 0.5                 # 添加dropout
        }
        
        # 创建数据集
        train_data = lgb.Dataset(X_train, label=y_train)
        val_data = lgb.Dataset(X_val, label=y_val, reference=train_data)
        
        # 训练模型
        self.model = lgb.train(
            params,
            train_data,
            num_boost_round=params['num_iterations'],
            valid_sets=[train_data, val_data],
            valid_names=['train', 'val'],
            callbacks=[
                lgb.early_stopping(stopping_rounds=50),
                lgb.log_evaluation(period=50)
            ]
        )
        
        # 获取特征重要性
        importance_dict = dict(zip(X_train.columns, self.model.feature_importance()))
        self.feature_importance = pd.DataFrame({
            'feature': list(importance_dict.keys()),
            'importance': list(importance_dict.values())
        }).sort_values('importance', ascending=False)
        
        # 保存特征重要性图
        plt.figure(figsize=(15, 8))
        sns.barplot(x='importance', y='feature', 
                   data=self.feature_importance.head(30))
        plt.title('Top 30 特征重要性')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'feature_importance.png'))
        plt.close()
        
        # 获取训练过程中的评估指标
        evals_result = self.model.best_score
        
        # 绘制训练过程中的评估指标
        plt.figure(figsize=(12, 6))
        
        # 绘制AUC
        plt.subplot(1, 2, 1)
        plt.plot(self.model.best_score['train']['auc'], label='训练集AUC')
        plt.plot(self.model.best_score['val']['auc'], label='验证集AUC')
        plt.title('训练过程中的AUC变化')
        plt.xlabel('迭代次数')
        plt.ylabel('AUC')
        plt.legend()
        
        # 绘制对数损失
        plt.subplot(1, 2, 2)
        plt.plot(self.model.best_score['train']['binary_logloss'], label='训练集对数损失')
        plt.plot(self.model.best_score['val']['binary_logloss'], label='验证集对数损失')
        plt.title('训练过程中的对数损失变化')
        plt.xlabel('迭代次数')
        plt.ylabel('对数损失')
        plt.legend()
        
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'training_metrics.png'))
        plt.close()
        
        self.logger.info("模型训练完成")
        self.print_memory_usage()
    
    def evaluate_model(self, X_val, y_val):
        """评估模型性能"""
        self.logger.info("正在评估模型...")
        self.print_memory_usage()
        
        # 预测
        y_pred_proba = self.model.predict(X_val)
        y_pred = (y_pred_proba > 0.5).astype(int)
        
        # 打印分类报告
        self.logger.info("\n分类报告:")
        report = classification_report(y_val, y_pred)
        self.logger.info(report)
        
        # 输出F1、Recall、Precision
        from sklearn.metrics import f1_score, recall_score, precision_score
        f1 = f1_score(y_val, y_pred)
        recall = recall_score(y_val, y_pred)
        precision = precision_score(y_val, y_pred)
        self.logger.info(f"F1: {f1:.4f}")
        self.logger.info(f"Recall: {recall:.4f}")
        self.logger.info(f"Precision: {precision:.4f}")
        
        # 计算ROC曲线和AUC
        from sklearn.metrics import roc_curve, auc
        fpr, tpr, _ = roc_curve(y_val, y_pred_proba)
        roc_auc = auc(fpr, tpr)
        
        # 绘制ROC曲线
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2, 
                 label=f'ROC curve (AUC = {roc_auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC曲线')
        plt.legend(loc="lower right")
        plt.savefig(os.path.join(self.output_dir, 'roc_curve.png'))
        plt.close()
        
        # 绘制混淆矩阵
        cm = confusion_matrix(y_val, y_pred)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('混淆矩阵')
        plt.ylabel('真实标签')
        plt.xlabel('预测标签')
        plt.savefig(os.path.join(self.output_dir, 'confusion_matrix.png'))
        plt.close()
        
        # 计算混淆矩阵的核心指标
        tn, fp, fn, tp = cm.ravel()
        
        # 计算四个核心评估指标
        accuracy = (tp + tn) / (tp + tn + fp + fn)
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
        
        self.logger.info("\n模型评估核心指标:")
        self.logger.info(f"准确率 (Accuracy): {accuracy:.4f}")
        self.logger.info(f"精确率 (Precision): {precision:.4f}")
        self.logger.info(f"召回率 (Recall): {recall:.4f}")
        self.logger.info(f"F1-Score: {f1:.4f}")
        
        # 将指标保存到CSV文件
        metrics_df = pd.DataFrame({
            '指标': ['准确率(Accuracy)', '精确率(Precision)', '召回率(Recall)', 'F1-Score'],
            '值': [accuracy, precision, recall, f1]
        })
        metrics_path = os.path.join(self.output_dir, 'model_metrics.csv')
        metrics_df.to_csv(metrics_path, index=False, encoding='utf-8')
        self.logger.info(f"\n评估指标已保存到: {metrics_path}")
        
        self.logger.info("模型评估完成")
        self.print_memory_usage()
    
    def save_model(self):
        """保存模型和相关信息"""
        self.logger.info("正在保存模型...")
        self.print_memory_usage()
        
        try:
            # 确保输出目录存在
            os.makedirs(self.output_dir, exist_ok=True)
            
            # 使用joblib保存模型
            model_path = os.path.join(self.output_dir, 'dga_detector.joblib')
            joblib.dump(self.model, model_path)
            self.logger.info(f"模型已保存到: {model_path}")
            
            # 保存特征重要性
            importance_path = os.path.join(self.output_dir, 'feature_importance.csv')
            self.feature_importance.to_csv(importance_path, index=False)
            self.logger.info(f"特征重要性已保存到: {importance_path}")
            
            # 保存训练信息
            info = {
                'model_type': 'LightGBM',
                'params': self.model.params,
                'feature_importance': self.feature_importance.to_dict()
            }
            info_path = os.path.join(self.output_dir, 'training_info.joblib')
            joblib.dump(info, info_path)
            self.logger.info(f"训练信息已保存到: {info_path}")
            
        except Exception as e:
            self.logger.error(f"保存模型时发生错误: {str(e)}")
            raise
        
        self.print_memory_usage()

    def run(self):
        """运行完整的训练流程（模仿xgb风格）"""
        try:
            # 加载总特征数据
            all_data_path = os.path.join(os.path.dirname(__file__), "output", "all_features.csv")
            df = pd.read_csv(all_data_path)
            # 划分特征和标签
            X = df.drop(['label', 'class'], axis=1)
            y = df['class']
            # 先划分训练+临时集
            X_train, X_temp, y_train, y_temp = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)
            # 再划分验证集和测试集
            X_val, X_test, y_val, y_test = train_test_split(X_temp, y_temp, test_size=0.5, random_state=42, stratify=y_temp)
            # 自动设置scale_pos_weight
            num_neg = (y_train == 0).sum()
            num_pos = (y_train == 1).sum()
            self.pos_weight = num_neg / num_pos if num_pos > 0 else 1.0
            self.logger.info(f"自动设置 scale_pos_weight: {self.pos_weight:.4f} (负样本/正样本)")
            # 训练模型
            self.train_model(X_train, y_train, X_val, y_val)
            # 评估模型（测试集）
            results = self.evaluate_model_return(X_test, y_test)
            # 保存模型
            self.save_model()
            # 清理内存
            del df, X_train, X_val, X_test, y_train, y_val, y_test
            gc.collect()
            return results
        except Exception as e:
            self.logger.error(f"训练过程出错: {str(e)}")
            raise

    def evaluate_model_return(self, X_val, y_val):
        """评估模型性能，返回主要指标字典（用于run方法）"""
        from sklearn.metrics import f1_score, recall_score, precision_score, roc_curve, auc, accuracy_score
        y_pred_proba = self.model.predict(X_val)
        y_pred = (y_pred_proba > 0.5).astype(int)
        f1 = f1_score(y_val, y_pred)
        recall = recall_score(y_val, y_pred)
        precision = precision_score(y_val, y_pred)
        accuracy = accuracy_score(y_val, y_pred)
        fpr, tpr, _ = roc_curve(y_val, y_pred_proba)
        roc_auc = auc(fpr, tpr)
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'auc': roc_auc
        }

def main():
    # 创建检测器实例
    detector = DGADetector()
    # 运行训练流程
    results = detector.run()
    print("\n训练完成！模型和评估结果已保存到", detector.output_dir)
    print("\n测试集评估结果:")
    print(f"准确率: {results['accuracy']:.4f}")
    print(f"精确率: {results['precision']:.4f}")
    print(f"召回率: {results['recall']:.4f}")
    print(f"F1分数: {results['f1']:.4f}")
    print(f"AUC: {results['auc']:.4f}")

if __name__ == "__main__":
    main() 