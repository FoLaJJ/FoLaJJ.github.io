import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import mutual_info_classif, VarianceThreshold
from sklearn.decomposition import PCA
import re
from collections import Counter
import tldextract
import warnings
import os
from tqdm import tqdm
import gc
import joblib
from nltk import ngrams
from nltk.lm import MLE
from nltk.lm.preprocessing import padded_everygram_pipeline
import nltk
import math
import logging

warnings.filterwarnings('ignore')


class DGAFeatureEngineering:
    def __init__(self, output_dir='output'):
        self.output_dir = output_dir
        self.feature_descriptions = {}
        self.tld_encoder = None
        self.selected_features = None
        self.batch_size = 100000
        self.is_first_batch = True
        self.tld_frequency = None

        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)

        # 设置日志
        self.setup_logging()

    def setup_logging(self):
        """设置日志记录"""
        # 创建日志记录器
        self.logger = logging.getLogger('DGAFeatureEngineering')
        self.logger.setLevel(logging.INFO)

        # 创建控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)

        # 创建文件处理器
        log_file = os.path.join(self.output_dir, 'feature_engineering.log')
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)

        # 创建格式化器
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)

        # 添加处理器到记录器
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)

        self.logger.info("日志系统初始化完成")

    def extract_domain_features(self, domain):
        """提取域名特征"""
        features = {}

        # 基础特征
        features['length'] = len(domain)
        features['entropy'] = self.calculate_entropy(domain)

        # 提取TLD和域名部分
        ext = tldextract.extract(domain)
        features['tld'] = ext.suffix if ext.suffix else 'unknown'
        features['domain_name'] = ext.domain if ext.domain else 'unknown'
        features['subdomain'] = ext.subdomain if ext.subdomain else 'unknown'

        # 域名结构特征
        parts = domain.split('.')
        features['num_parts'] = len(parts)  # 域名部分数量
        features['subdomain_count'] = len(parts) - 1  # 子域名数量
        features['main_domain_length'] = len(parts[-2]) if len(parts) > 1 else len(parts[0])  # 主域名长度
        features['tld_length'] = len(parts[-1])  # TLD长度
        features['subdomain_length'] = sum(len(p) for p in parts[:-1])  # 子域名总长度
        features['max_part_length'] = max(len(p) for p in parts)  # 最长部分长度
        features['min_part_length'] = min(len(p) for p in parts)  # 最短部分长度
        features['avg_part_length'] = sum(len(p) for p in parts) / len(parts)  # 平均部分长度

        # 字符统计特征
        features['num_digits'] = sum(c.isdigit() for c in domain)
        features['num_letters'] = sum(c.isalpha() for c in domain)
        features['num_special_chars'] = len(domain) - features['num_digits'] - features['num_letters']
        features['num_vowels'] = sum(c.lower() in 'aeiou' for c in domain)
        features['num_consonants'] = sum(c.lower() in 'bcdfghjklmnpqrstvwxyz' for c in domain)

        # 字符比例特征
        features['digit_ratio'] = features['num_digits'] / len(domain) if len(domain) > 0 else 0
        features['letter_ratio'] = features['num_letters'] / len(domain) if len(domain) > 0 else 0
        features['special_char_ratio'] = features['num_special_chars'] / len(domain) if len(domain) > 0 else 0
        features['vowel_ratio'] = features['num_vowels'] / features['num_letters'] if features['num_letters'] > 0 else 0
        features['consonant_ratio'] = features['num_consonants'] / features['num_letters'] if features[
                                                                                                  'num_letters'] > 0 else 0

        # 位置特征
        features['digit_first_pos'] = next((i for i, c in enumerate(domain) if c.isdigit()), -1)
        features['digit_last_pos'] = len(domain) - next((i for i, c in enumerate(reversed(domain)) if c.isdigit()),
                                                        -1) - 1
        features['special_char_first_pos'] = next((i for i, c in enumerate(domain) if not c.isalnum()), -1)
        features['special_char_last_pos'] = len(domain) - next(
            (i for i, c in enumerate(reversed(domain)) if not c.isalnum()), -1) - 1

        # 连续字符特征
        features['max_consecutive_digits'] = self.max_consecutive_chars(domain, str.isdigit)
        features['max_consecutive_letters'] = self.max_consecutive_chars(domain, str.isalpha)
        features['max_consecutive_special'] = self.max_consecutive_chars(domain, lambda x: not x.isalnum())

        # 重复模式特征
        features['max_2gram_repetition'] = self.max_ngram_repetition(domain, 2)
        features['max_3gram_repetition'] = self.max_ngram_repetition(domain, 3)
        features['repeated_2gram_count'] = self.count_repeated_ngrams(domain, 2)
        features['repeated_3gram_count'] = self.count_repeated_ngrams(domain, 3)

        # 键盘序列特征
        features['keyboard_qwerty_seq'] = self.keyboard_sequence(domain, 'qwerty')
        features['keyboard_num_seq'] = self.keyboard_sequence(domain, 'num')

        # 转移概率特征
        features['transition_alpha_alpha'] = self.transition_probability(domain, str.isalpha, str.isalpha)
        features['transition_alpha_digit'] = self.transition_probability(domain, str.isalpha, str.isdigit)
        features['transition_digit_alpha'] = self.transition_probability(domain, str.isdigit, str.isalpha)
        features['transition_digit_digit'] = self.transition_probability(domain, str.isdigit, str.isdigit)

        # 新增：域名结构比例特征
        features['subdomain_ratio'] = features['subdomain_length'] / len(domain) if len(domain) > 0 else 0
        features['main_domain_ratio'] = features['main_domain_length'] / len(domain) if len(domain) > 0 else 0
        features['tld_ratio'] = features['tld_length'] / len(domain) if len(domain) > 0 else 0

        # 新增：字符分布特征
        features['char_distribution'] = self.calculate_char_distribution(domain)
        features['digit_distribution'] = self.calculate_digit_distribution(domain)
        features['special_char_distribution'] = self.calculate_special_char_distribution(domain)

        # 新增：n-gram频率特征
        features['bigram_freq'] = self.calculate_ngram_frequency(domain, 2)
        features['trigram_freq'] = self.calculate_ngram_frequency(domain, 3)

        # 新增：域名复杂度特征
        features['domain_complexity'] = self.calculate_domain_complexity(domain)
        features['pattern_variety'] = self.calculate_pattern_variety(domain)

        return features

    def calculate_char_distribution(self, domain):
        """计算字符分布特征"""
        if not domain:
            return 0

        # 计算每个字符的频率
        char_freq = {}
        for char in domain:
            char_freq[char] = char_freq.get(char, 0) + 1

        # 计算分布的均匀性
        total_chars = len(domain)
        expected_freq = total_chars / len(char_freq) if char_freq else 0
        variance = sum((freq - expected_freq) ** 2 for freq in char_freq.values()) / len(char_freq) if char_freq else 0

        return variance / total_chars if total_chars > 0 else 0

    def calculate_digit_distribution(self, domain):
        """计算数字分布特征"""
        digits = ''.join(c for c in domain if c.isdigit())
        if not digits:
            return 0

        # 计算数字的分布
        digit_freq = {}
        for digit in digits:
            digit_freq[digit] = digit_freq.get(digit, 0) + 1

        # 计算分布的均匀性
        total_digits = len(digits)
        expected_freq = total_digits / len(digit_freq) if digit_freq else 0
        variance = sum((freq - expected_freq) ** 2 for freq in digit_freq.values()) / len(
            digit_freq) if digit_freq else 0

        return variance / total_digits if total_digits > 0 else 0

    def calculate_special_char_distribution(self, domain):
        """计算特殊字符分布特征"""
        special_chars = ''.join(c for c in domain if not c.isalnum())
        if not special_chars:
            return 0

        # 计算特殊字符的分布
        special_freq = {}
        for char in special_chars:
            special_freq[char] = special_freq.get(char, 0) + 1

        # 计算分布的均匀性
        total_special = len(special_chars)
        expected_freq = total_special / len(special_freq) if special_freq else 0
        variance = sum((freq - expected_freq) ** 2 for freq in special_freq.values()) / len(
            special_freq) if special_freq else 0

        return variance / total_special if total_special > 0 else 0

    def calculate_ngram_frequency(self, domain, n):
        """计算n-gram频率特征"""
        if len(domain) < n:
            return 0

        # 生成n-grams
        ngrams = [domain[i:i + n] for i in range(len(domain) - n + 1)]

        # 计算n-gram频率
        ngram_freq = {}
        for ngram in ngrams:
            ngram_freq[ngram] = ngram_freq.get(ngram, 0) + 1

        # 计算频率的方差
        total_ngrams = len(ngrams)
        expected_freq = total_ngrams / len(ngram_freq) if ngram_freq else 0
        variance = sum((freq - expected_freq) ** 2 for freq in ngram_freq.values()) / len(
            ngram_freq) if ngram_freq else 0

        return variance / total_ngrams if total_ngrams > 0 else 0

    def calculate_domain_complexity(self, domain):
        """计算域名复杂度特征"""
        if not domain:
            return 0

        # 计算不同字符类型的数量
        char_types = sum(1 for c in set(domain) if c.isalpha()) + \
                     sum(1 for c in set(domain) if c.isdigit()) + \
                     sum(1 for c in set(domain) if not c.isalnum())

        # 计算字符类型比例
        type_ratio = char_types / len(set(domain)) if domain else 0

        # 计算字符转换次数
        transitions = sum(1 for i in range(len(domain) - 1)
                          if (domain[i].isalpha() != domain[i + 1].isalpha()) or
                          (domain[i].isdigit() != domain[i + 1].isdigit()))

        return (type_ratio + transitions / len(domain)) / 2 if domain else 0

    def calculate_pattern_variety(self, domain):
        """计算模式多样性特征"""
        if not domain:
            return 0

        # 计算不同字符序列的长度
        sequences = []
        current_seq = [domain[0]]

        for i in range(1, len(domain)):
            if (domain[i].isalpha() == domain[i - 1].isalpha() and
                    domain[i].isdigit() == domain[i - 1].isdigit() and
                    (not domain[i].isalnum()) == (not domain[i - 1].isalnum())):
                current_seq.append(domain[i])
            else:
                sequences.append(len(current_seq))
                current_seq = [domain[i]]

        sequences.append(len(current_seq))

        # 计算序列长度的方差
        if not sequences:
            return 0

        mean_length = sum(sequences) / len(sequences)
        variance = sum((length - mean_length) ** 2 for length in sequences) / len(sequences)

        return variance / mean_length if mean_length > 0 else 0

    def max_consecutive_chars(self, string, char_type_func):
        """计算最大连续字符长度"""
        max_count = 0
        current_count = 0

        for char in string:
            if char_type_func(char):
                current_count += 1
                max_count = max(max_count, current_count)
            else:
                current_count = 0

        return max_count

    def max_ngram_repetition(self, string, n):
        """计算最大n-gram重复次数"""
        if len(string) < n:
            return 0

        ngrams = [string[i:i + n] for i in range(len(string) - n + 1)]
        ngram_counts = {}

        for ngram in ngrams:
            ngram_counts[ngram] = ngram_counts.get(ngram, 0) + 1

        return max(ngram_counts.values()) if ngram_counts else 0

    def count_repeated_ngrams(self, string, n):
        """计算重复n-gram的数量"""
        if len(string) < n:
            return 0

        ngrams = [string[i:i + n] for i in range(len(string) - n + 1)]
        ngram_counts = {}

        for ngram in ngrams:
            ngram_counts[ngram] = ngram_counts.get(ngram, 0) + 1

        return sum(1 for count in ngram_counts.values() if count > 1)

    def keyboard_sequence(self, string, keyboard_type):
        """检测键盘序列"""
        if keyboard_type == 'qwerty':
            keyboard = 'qwertyuiopasdfghjklzxcvbnm'
        else:  # num
            keyboard = '1234567890'

        max_seq = 0
        current_seq = 0

        for i in range(len(string) - 1):
            if string[i].lower() in keyboard and string[i + 1].lower() in keyboard:
                idx1 = keyboard.find(string[i].lower())
                idx2 = keyboard.find(string[i + 1].lower())
                if abs(idx1 - idx2) == 1:
                    current_seq += 1
                    max_seq = max(max_seq, current_seq)
                else:
                    current_seq = 0
            else:
                current_seq = 0

        return max_seq

    def transition_probability(self, string, from_type, to_type):
        """计算字符类型转移概率"""
        if len(string) < 2:
            return 0

        transitions = 0
        total_possible = 0

        for i in range(len(string) - 1):
            if from_type(string[i]):
                total_possible += 1
                if to_type(string[i + 1]):
                    transitions += 1

        return transitions / total_possible if total_possible > 0 else 0

    def calculate_entropy(self, string):
        """计算字符串熵值"""
        if not string:
            return 0

        # 计算字符频率
        freq = {}
        for char in string:
            freq[char] = freq.get(char, 0) + 1

        # 计算熵值
        entropy = 0
        for count in freq.values():
            probability = count / len(string)
            entropy -= probability * math.log2(probability)

        return entropy

    def clean_data(self, df):
        """改进的数据清洗"""
        print("正在进行数据清洗...")

        # 删除重复数据
        df = df.drop_duplicates()

        # 删除空值
        df = df.dropna()

        # 使用更合理的长度限制
        length_percentiles = df['domain'].str.len().quantile([0.01, 0.99])
        min_length = int(length_percentiles[0.01])
        max_length = int(length_percentiles[0.99])

        # 使用百分位数作为过滤标准
        df = df[
            (df['domain'].str.len() >= min_length) &
            (df['domain'].str.len() <= max_length)
            ]

        # 优化数据类型
        df['class'] = df['class'].astype('int8')
        df['domain'] = df['domain'].astype('string')
        df['label'] = df['label'].astype('category')

        return df

    def extract_sequence_features(self, domain):
        """提取序列特征"""
        features = {}

        # N-gram特征
        for n in [2, 3]:
            ngrams_list = list(ngrams(domain, n))
            ngram_freq = Counter(ngrams_list)
            features[f'ngram_{n}_entropy'] = self._calculate_entropy(''.join([''.join(ng) for ng in ngrams_list]))
            features[f'ngram_{n}_unique_ratio'] = len(set(ngrams_list)) / len(ngrams_list)

        # 键盘序列特征
        keyboard_patterns = {
            'qwerty': 'qwertyuiopasdfghjklzxcvbnm',
            'num': '1234567890',
            'symbol': '!@#$%^&*()_+-=[]{}|;:,.<>?'
        }

        for pattern_name, pattern in keyboard_patterns.items():
            features[f'keyboard_{pattern_name}_seq'] = 0
            for i in range(len(domain) - 1):
                if domain[i:i + 2].lower() in pattern:
                    features[f'keyboard_{pattern_name}_seq'] = 1
                    break

        return features

    def extract_semantic_features(self, domain):
        """提取语义特征"""
        features = {}

        # 词典匹配
        common_words = set(['www', 'mail', 'ftp', 'smtp', 'pop', 'imap', 'web', 'blog', 'shop', 'store'])
        domain_words = set(domain.split('.'))
        features['common_word_ratio'] = len(domain_words & common_words) / len(domain_words)

        # 语言模型特征
        if self.language_model:
            features['language_model_score'] = self._calculate_language_model_score(domain)
        else:
            features['language_model_score'] = 0

        # 域名可读性特征
        features['readability_score'] = self._calculate_readability_score(domain)

        return features

    def _calculate_language_model_score(self, domain):
        """计算语言模型得分"""
        try:
            # 使用3-gram语言模型
            tokens = list(domain)
            padded_sentences = list(padded_everygram_pipeline(3, [tokens]))
            return self.language_model.perplexity(padded_sentences[0])
        except:
            return 0

    def _calculate_readability_score(self, domain):
        """计算域名可读性得分"""
        # 基于字符类型转换的频率
        transitions = 0
        prev_type = None

        for char in domain:
            if char.isalpha():
                curr_type = 'alpha'
            elif char.isdigit():
                curr_type = 'digit'
            else:
                curr_type = 'special'

            if prev_type and curr_type != prev_type:
                transitions += 1
            prev_type = curr_type

        return transitions / len(domain)

    def extract_position_features(self, domain):
        """提取字符位置分布特征"""
        features = {}

        # 特殊字符位置分布
        special_chars = ['.', '-', '_', '/', '?', '=', '@', '&', '!', ' ', '~', ',', '+', '*', '#', '$', '%']
        for char in special_chars:
            positions = [i for i, c in enumerate(domain) if c == char]
            if positions:
                features[f'{char}_first_pos'] = positions[0] / len(domain)
                features[f'{char}_last_pos'] = positions[-1] / len(domain)
                features[f'{char}_pos_std'] = np.std(positions) / len(domain)

        # 数字位置分布
        digit_positions = [i for i, c in enumerate(domain) if c.isdigit()]
        if digit_positions:
            features['digit_first_pos'] = digit_positions[0] / len(domain)
            features['digit_last_pos'] = digit_positions[-1] / len(domain)
            features['digit_pos_std'] = np.std(digit_positions) / len(domain)

        return features

    def extract_consecutive_features(self, domain):
        """提取连续字符统计特征"""
        features = {}

        # 连续数字
        consecutive_digits = 0
        max_consecutive_digits = 0
        for i in range(len(domain)):
            if domain[i].isdigit():
                consecutive_digits += 1
                max_consecutive_digits = max(max_consecutive_digits, consecutive_digits)
            else:
                consecutive_digits = 0
        features['max_consecutive_digits'] = max_consecutive_digits

        # 连续特殊字符
        consecutive_special = 0
        max_consecutive_special = 0
        for i in range(len(domain)):
            if not domain[i].isalnum():
                consecutive_special += 1
                max_consecutive_special = max(max_consecutive_special, consecutive_special)
            else:
                consecutive_special = 0
        features['max_consecutive_special'] = max_consecutive_special

        return features

    def extract_repetition_features(self, domain):
        """提取重复模式特征"""
        features = {}

        # 计算2-3字符的重复模式
        for n in [2, 3]:
            patterns = [domain[i:i + n] for i in range(len(domain) - n + 1)]
            pattern_counts = Counter(patterns)
            repeated_patterns = {p: c for p, c in pattern_counts.items() if c > 1}

            features[f'repeated_{n}gram_count'] = len(repeated_patterns)
            features[f'repeated_{n}gram_ratio'] = len(repeated_patterns) / len(patterns)
            if repeated_patterns:
                features[f'max_{n}gram_repetition'] = max(repeated_patterns.values())

        return features

    def extract_transition_features(self, domain):
        """提取字符转移概率特征"""
        features = {}

        # 字符类型转移
        transitions = []
        prev_type = None
        for char in domain:
            if char.isalpha():
                curr_type = 'alpha'
            elif char.isdigit():
                curr_type = 'digit'
            else:
                curr_type = 'special'

            if prev_type:
                transitions.append(f"{prev_type}_{curr_type}")
            prev_type = curr_type

        # 计算转移概率
        transition_counts = Counter(transitions)
        total_transitions = len(transitions)

        for transition in ['alpha_alpha', 'alpha_digit', 'alpha_special',
                           'digit_alpha', 'digit_digit', 'digit_special',
                           'special_alpha', 'special_digit', 'special_special']:
            features[f'transition_{transition}'] = transition_counts.get(transition, 0) / total_transitions

        return features

    def extract_structure_features(self, domain):
        """提取域名结构特征"""
        features = {}

        # 分割域名
        parts = domain.split('.')

        # 计算各部分长度比例
        total_length = len(domain)
        for i, part in enumerate(parts):
            features[f'part_{i}_length_ratio'] = len(part) / total_length

        # 计算子域名深度
        features['subdomain_depth'] = len(parts) - 1

        # 计算各部分字符类型比例
        for i, part in enumerate(parts):
            features[f'part_{i}_digit_ratio'] = sum(1 for c in part if c.isdigit()) / len(part)
            features[f'part_{i}_alpha_ratio'] = sum(1 for c in part if c.isalpha()) / len(part)
            features[f'part_{i}_special_ratio'] = sum(1 for c in part if not c.isalnum()) / len(part)

        return features

    def process_tld_features(self, feature_df):
        """处理TLD特征"""
        if self.is_first_batch:
            # 计算TLD频率
            tld_counts = feature_df['tld'].value_counts()
            self.tld_frequency = (tld_counts / len(feature_df)).to_dict()

            # 保存TLD编码器
            joblib.dump(self.tld_frequency, os.path.join(self.output_dir, 'tld_encoder.joblib'))

        # 应用频率编码
        feature_df['tld_freq'] = feature_df['tld'].map(self.tld_frequency)
        feature_df['tld_freq_log'] = np.log1p(feature_df['tld_freq'])

        # 删除原始TLD列
        feature_df = feature_df.drop(['tld', 'domain_name', 'subdomain'], axis=1)

        return feature_df

    def handle_missing_values(self, feature_df):
        """处理缺失值"""
        numeric_cols = feature_df.select_dtypes(include=['float64', 'int64']).columns
        categorical_cols = feature_df.select_dtypes(include=['category']).columns

        # 数值特征：使用中位数填充
        for col in numeric_cols:
            median_value = feature_df[col].median()
            feature_df[col] = feature_df[col].fillna(median_value)

        # 分类特征：使用众数填充
        for col in categorical_cols:
            mode_value = feature_df[col].mode()[0]
            feature_df[col] = feature_df[col].fillna(mode_value)

        return feature_df

    def select_features(self, X, y, k=30):
        """改进的特征选择"""
        print("开始特征选择...")

        # 使用互信息
        mi_scores = mutual_info_classif(X, y)

        # 使用方差阈值
        selector = VarianceThreshold(threshold=0.01)
        X_var = selector.fit_transform(X)
        var_features = X.columns[selector.get_support()].tolist()

        # 使用相关性分析
        corr_matrix = X.corr().abs()
        upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        to_drop = [column for column in upper.columns if any(upper[column] > 0.95)]

        # 综合选择
        feature_importance = pd.DataFrame({
            'feature': X.columns,
            'mi_score': mi_scores,
            'variance_selected': X.columns.isin(var_features),
            'correlation_selected': ~X.columns.isin(to_drop)
        })

        # 选择满足条件的特征
        selected_features = feature_importance[
            (feature_importance['variance_selected']) &
            (feature_importance['correlation_selected'])
            ].nlargest(k, 'mi_score')['feature'].tolist()

        print(f"选择了 {len(selected_features)} 个特征")
        return X[selected_features], selected_features

    def process_batch(self, batch_df, batch_num, dataset_name, output_file):
        """处理一批数据"""
        print(f"\n处理{dataset_name}数据集第{batch_num}批...")

        # 提取域名特征
        domain_features = []
        for domain in tqdm(batch_df['domain'], desc="提取域名特征"):
            features = self.extract_domain_features(domain)
            domain_features.append(features)

        feature_df = pd.DataFrame(domain_features)

        # 处理TLD特征
        feature_df = self.process_tld_features(feature_df)

        # 处理缺失值
        feature_df = self.handle_missing_values(feature_df)

        # 添加标签
        feature_df['label'] = batch_df['label'].values
        feature_df['class'] = batch_df['class'].values

        # 保存到CSV
        mode = 'w' if batch_num == 1 else 'a'
        header = batch_num == 1
        feature_df.to_csv(output_file, mode=mode, header=header, index=False)
        print(f"已追加到: {output_file}")

        # 清理内存
        del feature_df, batch_df, domain_features
        gc.collect()

    def select_and_save_features(self):
        """在所有数据集处理完成后进行特征选择"""
        print("\n开始特征选择...")

        # 读取所有数据集
        train_df = pd.read_csv(os.path.join(self.output_dir, 'train_features.csv'))
        valid_df = pd.read_csv(os.path.join(self.output_dir, 'validation_features.csv'))
        test_df = pd.read_csv(os.path.join(self.output_dir, 'test_features.csv'))

        # 获取所有数据集的特征列（排除class和label）
        train_features = set(col for col in train_df.columns if col not in ['class', 'label'])
        valid_features = set(col for col in valid_df.columns if col not in ['class', 'label'])
        test_features = set(col for col in test_df.columns if col not in ['class', 'label'])

        # 找出所有数据集共有的特征
        self.selected_features = list(train_features & valid_features & test_features)

        # 保存选择的特征
        pd.DataFrame({'feature_name': self.selected_features}).to_csv(
            os.path.join(self.output_dir, 'selected_features.csv'),
            index=False
        )

        # 保存特征说明
        feature_info = {
            'selected_features': self.selected_features,
            'feature_descriptions': {k: self.feature_descriptions[k] for k in self.selected_features if
                                     k in self.feature_descriptions}
        }
        joblib.dump(feature_info, os.path.join(self.output_dir, 'feature_info.joblib'))

        # 生成特征说明文档
        with open(os.path.join(self.output_dir, 'feature_descriptions.txt'), 'w', encoding='utf-8') as f:
            f.write("特征说明文档\n")
            f.write("=" * 50 + "\n\n")
            f.write("选中的特征及其说明：\n")
            f.write("-" * 50 + "\n")
            for feature in self.selected_features:
                if feature in self.feature_descriptions:
                    f.write(f"{feature}: {self.feature_descriptions[feature]}\n")
                else:
                    f.write(f"{feature}: 数值特征\n")
            f.write("\n标签说明：\n")
            f.write("-" * 50 + "\n")
            f.write("class: 0表示合法域名，1表示DGA域名\n")
            f.write("label: 详细的域名类型标签\n")

        print(f"已选择 {len(self.selected_features)} 个特征")
        print("特征选择完成！")

    def process_dataset(self, df, dataset_name):
        """处理整个数据集"""
        print(f"\n开始处理{dataset_name}数据集...")
        df = self.clean_data(df)

        # 设置输出文件
        output_file = os.path.join(self.output_dir, f'{dataset_name}_features.csv')

        # 分批处理
        total_samples = len(df)
        num_batches = (total_samples + self.batch_size - 1) // self.batch_size

        for i in range(num_batches):
            start_idx = i * self.batch_size
            end_idx = min((i + 1) * self.batch_size, total_samples)
            batch_df = df.iloc[start_idx:end_idx]
            self.process_batch(batch_df, i + 1, dataset_name, output_file)
            del batch_df
            gc.collect()


def analyze_dataset(df, dataset_name):
    """分析数据集的基本信息"""
    print(f"\n{dataset_name}数据集分析:")
    print("-" * 50)

    # 基本统计信息
    print(f"总样本数: {len(df)}")

    # 类别分布
    class_dist = df['class'].value_counts()
    print("\n类别分布:")
    for class_val, count in class_dist.items():
        percentage = (count / len(df)) * 100
        print(f"类别 {class_val} ({'合法' if class_val == 0 else '非法'}): {count} 样本 ({percentage:.2f}%)")

    # 详细标签分布
    print("\n详细标签分布:")
    label_dist = df['label'].value_counts()
    for label, count in label_dist.items():
        percentage = (count / len(df)) * 100
        print(f"{label}: {count} 样本 ({percentage:.2f}%)")

    # 域名长度统计
    print("\n域名长度统计:")
    df['domain_length'] = df['domain'].str.len()
    length_stats = df['domain_length'].describe()
    print(f"最小长度: {length_stats['min']:.2f}")
    print(f"最大长度: {length_stats['max']:.2f}")
    print(f"平均长度: {length_stats['mean']:.2f}")
    print(f"中位数长度: {length_stats['50%']:.2f}")

    print("-" * 50)


def main():
    # 创建output文件夹
    output_dir = os.path.join(os.path.dirname(__file__), "output")
    os.makedirs(output_dir, exist_ok=True)

    # 加载数据
    print("正在加载数据集...")
    from datasets import load_dataset

    data_dir = os.path.join(os.path.dirname(__file__), "data")
    ds = load_dataset(
        "harpomaxx/dga-detection",
        cache_dir=data_dir,
        trust_remote_code=True
    )

    # 转换为DataFrame
    train_df = pd.DataFrame(ds['train'])
    test_df = pd.DataFrame(ds['test'])
    valid_df = pd.DataFrame(ds['validation'])

    # 分析数据集
    analyze_dataset(train_df, "训练")
    analyze_dataset(test_df, "测试")
    analyze_dataset(valid_df, "验证")

    # 初始化特征工程类
    fe = DGAFeatureEngineering(output_dir)

    # 处理数据集
    fe.process_dataset(train_df, "train")
    fe.process_dataset(test_df, "test")
    fe.process_dataset(valid_df, "validation")

    # 在所有数据集处理完成后进行特征选择
    fe.select_and_save_features()

    print("\n处理完成！所有文件已保存到", output_dir)


if __name__ == "__main__":
    main() 