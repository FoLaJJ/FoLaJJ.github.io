from datasets import load_dataset
import os

# 设置缓存路径（项目下的data目录）
data_dir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(data_dir, exist_ok=True)

# 下载数据集（授权远程代码）
try:
    ds = load_dataset(
        "harpomaxx/dga-detection",
        cache_dir=data_dir,
        trust_remote_code=True
    )
    print("数据集加载成功！样本示例：")
    print(ds["train"][:5])
except Exception as e:
    print("加载失败：", str(e))