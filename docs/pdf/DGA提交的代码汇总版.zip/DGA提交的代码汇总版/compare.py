import matplotlib.pyplot as plt
import numpy as np
from typing import Dict, List


def plot_metrics_comparison(metrics_data: Dict[str, Dict[str, float]],
                            title: str = "Model Performance Comparison",
                            figsize: tuple = (12, 6)):
    """
    绘制多个模型指标的柱状图比较（使用默认颜色方案）

    参数:
        metrics_data: 字典格式的指标数据，例如:
            {
                "DT": {"Accuracy": 0.89, "Precision": 0.95, ...},
                "RF": {"Accuracy": 0.91, "Precision": 0.96, ...},
                ...
            }
        title: 图表标题
        figsize: 图表大小
    """
    # 提取模型名称和指标名称
    models = list(metrics_data.keys())
    metrics = list(metrics_data[models[0]].keys())

    # 创建图表
    fig, ax = plt.subplots(figsize=figsize)

    # 设置柱状图位置和宽度
    bar_width = 0.15
    x = np.arange(len(models))

    # 绘制每个指标的柱状图（使用默认颜色）
    for i, metric in enumerate(metrics):
        values = [metrics_data[model][metric] for model in models]
        bars = ax.bar(x + i * bar_width, values, bar_width, label=metric)

        # 在柱子上方添加数值标签
        for bar in bars:
            height = bar.get_height()
            ax.annotate(f'{height:.3f}',
                        xy=(bar.get_x() + bar.get_width() / 2, height),
                        xytext=(0, 3),  # 3 points vertical offset
                        textcoords="offset points",
                        ha='center', va='bottom', fontsize=9)

    # 添加图表元素
    ax.set_xlabel('Models', fontsize=12)
    ax.set_ylabel('Score', fontsize=12)
    ax.set_title(title, fontsize=14, pad=20)
    ax.set_xticks(x + bar_width * (len(metrics) - 1) / 2)
    ax.set_xticklabels(models)
    ax.legend(loc='upper left', bbox_to_anchor=(1, 1))
    ax.grid(axis='y', linestyle='--', alpha=0.7)

    # 自动调整y轴范围
    all_values = [value for model_data in metrics_data.values() for value in model_data.values()]
    ax.set_ylim(max(min(all_values) - 0.05, 0), min(max(all_values) + 0.05, 1.05))
    # ax.set_ylim(max(0.90, 0), min(max(0.98,0),1.05))

    plt.tight_layout()
    plt.savefig('score-compa.png')
    plt.show()


# 示例数据
metrics_data = {
    "DT": {
        "Accuracy": 0.820,
        "Precision": 0.930,
        "Recall": 0.786,
        "F1-Score": 0.852
    },
    "RF": {
        "Accuracy": 0.855,
        "Precision": 0.846,
        "Recall": 0.954,
        "F1-Score": 0.897
    },
    "LGB": {
        "Accuracy": 0.933,
        "Precision": 0.976,
        "Recall": 0.922,
        "F1-Score": 0.948
    },
    "CatBoost":{
        "Accuracy": 0.915,
        "Precision": 0.962,
        "Recall": 0.906,
        "F1-Score": 0.933
    },
    "XGB": {
        "Accuracy": 0.936,
        "Precision": 0.949,
        "Recall": 0.954,
        "F1-Score": 0.951
    }
}

# 绘制初始图表
plot_metrics_comparison(metrics_data)