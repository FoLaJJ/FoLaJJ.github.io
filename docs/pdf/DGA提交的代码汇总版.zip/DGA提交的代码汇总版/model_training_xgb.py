# 本文件用于训练DGA检测的XGBoost模型
# 输出全部保存在 model/xgb/ 目录下

import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, cross_val_score
import xgboost as xgb
from sklearn.metrics import classification_report, confusion_matrix, roc_auc_score, accuracy_score, precision_score, recall_score, f1_score, roc_curve
import joblib
import os
import matplotlib.pyplot as plt
import seaborn as sns
from datetime import datetime
from tqdm import tqdm
import gc
import psutil
import warnings
import logging
from io import StringIO
import sys
from sklearn.model_selection import KFold
from bayes_opt import BayesianOptimization
import json
warnings.filterwarnings('ignore')
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

class StreamToLogger:
    def __init__(self, logger, level):
        self.logger = logger
        self.level = level
        self.linebuf = ''

    def write(self, buf):
        for line in buf.rstrip().splitlines():
            self.logger.log(self.level, line.rstrip())

    def flush(self):
        pass

class XGBoostTrainer:
    def __init__(self, output_dir='model/xgb'):
        self.output_dir = output_dir
        self.model = None
        self.feature_importance = None
        self.selected_features = None
        
        # 定义模型参数
        self.params = {
            'max_depth': 20,  # 减小深度，防止过拟合
            'learning_rate': 0.01,  # 减小学习率，提高稳定性
            'n_estimators': 2000,  # 减少迭代次数
            'min_child_weight': 3,  # 增加最小子节点权重
            'subsample': 0.6,  # 减小采样比例，增加随机性
            'colsample_bytree': 0.6,  # 减小特征采样比例
            'gamma': 0.2,  # 增加分裂阈值
            'tree_method': 'hist',  # 使用直方图优化
            'random_state': 42,
            'reg_alpha': 2.0,  # 增加L1正则化
            'reg_lambda': 3.0,  # 增加L2正则化
            'objective': 'binary:logistic',
            'eval_metric': ['auc', 'error', 'logloss']
        }
        
        # 创建输出目录
        os.makedirs(output_dir, exist_ok=True)
        
        # 设置日志
        self.setup_logging()
        
    def setup_logging(self):
        """设置日志记录"""
        # 创建日志记录器
        self.logger = logging.getLogger('XGBoostTrainer')
        self.logger.setLevel(logging.INFO)
        
        # 创建控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # 创建文件处理器
        log_file = os.path.join(self.output_dir, 'training.log')
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.INFO)
        
        # 创建格式化器
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        file_handler.setFormatter(formatter)
        
        # 添加处理器到记录器
        self.logger.addHandler(console_handler)
        self.logger.addHandler(file_handler)
        
        self.logger.info("日志系统初始化完成")
    
    def load_data(self):
        """加载数据"""
        self.logger.info("开始加载数据...")
        
        # 读取选择的特征
        selected_features = pd.read_csv('output/selected_features.csv')['feature_name'].tolist()
        selected_features.extend(['class', 'label'])
        self.selected_features = selected_features
        
        # 读取完整数据集
        self.logger.info("从all_features.csv加载数据...")
        all_data = pd.read_csv('output/all_features.csv')
        
        # 使用选择的特征
        all_data = all_data[selected_features]
        
        # 检查数据分布
        self.logger.info("\n原始数据分布:")
        self.logger.info(all_data['class'].value_counts(normalize=True))
        
        # 按照7:1:2的比例划分训练集、验证集和测试集
        train_df, temp_df = train_test_split(all_data, test_size=0.3, random_state=42, stratify=all_data['class'])
        val_df, test_df = train_test_split(temp_df, test_size=0.67, random_state=42, stratify=temp_df['class'])
        
        self.logger.info("\n划分后的数据分布:")
        self.logger.info("训练集类别分布:")
        self.logger.info(train_df['class'].value_counts(normalize=True))
        self.logger.info("验证集类别分布:")
        self.logger.info(val_df['class'].value_counts(normalize=True))
        self.logger.info("测试集类别分布:")
        self.logger.info(test_df['class'].value_counts(normalize=True))
        
        # 分离特征和标签
        self.X_train = train_df.drop(['class', 'label'], axis=1)
        self.y_train = train_df['class']
        self.X_val = val_df.drop(['class', 'label'], axis=1)
        self.y_val = val_df['class']
        self.X_test = test_df.drop(['class', 'label'], axis=1)
        self.y_test = test_df['class']
        
        # 检查特征
        self.logger.info(f"\n特征数量: {len(self.X_train.columns)}")
        self.logger.info("特征列表:")
        self.logger.info(self.X_train.columns.tolist())
        
        self.logger.info(f"\n数据加载完成。训练集大小: {len(self.X_train)}, 验证集大小: {len(self.X_val)}, 测试集大小: {len(self.X_test)}")
    
    def train_model(self):
        """训练模型"""
        self.logger.info("开始训练模型...")
        
        # 计算类别权重
        neg_count = len(self.y_train[self.y_train == 0])
        pos_count = len(self.y_train[self.y_train == 1])
        self.logger.info(f"正样本数量: {pos_count}, 负样本数量: {neg_count}")
        self.logger.info(f"正负样本比例: {pos_count/neg_count:.4f}")
        
        # 使用较大的类别权重调整，提高召回率
        scale_pos_weight = 1.3  # 显著增加正样本权重
        
        # 更新scale_pos_weight参数
        self.params['scale_pos_weight'] = scale_pos_weight
        
        # 创建DMatrix对象
        dtrain = xgb.DMatrix(self.X_train, label=self.y_train)
        dval = xgb.DMatrix(self.X_val, label=self.y_val)
        
        # 用于存储评估结果
        evals_result = {}
        
        # 训练模型
        self.model = xgb.train(
            self.params,
            dtrain,
            num_boost_round=self.params['n_estimators'],
            evals=[(dtrain, 'train'), (dval, 'val')],
            early_stopping_rounds=50,  # 减少早停轮数，避免过拟合
            verbose_eval=50,
            evals_result=evals_result
        )
        
        # 分析训练过程
        best_iteration = self.model.best_iteration
        self.logger.info(f"最佳迭代次数: {best_iteration}")
        self.logger.info(f"训练集最终AUC: {evals_result['train']['auc'][best_iteration]:.4f}")
        self.logger.info(f"验证集最终AUC: {evals_result['val']['auc'][best_iteration]:.4f}")
        self.logger.info(f"训练集最终错误率: {evals_result['train']['error'][best_iteration]:.4f}")
        self.logger.info(f"验证集最终错误率: {evals_result['val']['error'][best_iteration]:.4f}")
        self.logger.info(f"训练集最终logloss: {evals_result['train']['logloss'][best_iteration]:.4f}")
        self.logger.info(f"验证集最终logloss: {evals_result['val']['logloss'][best_iteration]:.4f}")
        
        self.logger.info("模型训练完成")
    
    def evaluate_model(self):
        """评估模型"""
        self.logger.info("开始评估模型...")
        
        # 预测
        y_pred = self.model.predict(xgb.DMatrix(self.X_test))
        y_pred_binary = (y_pred > 0.5).astype(int)
        
        # 计算评估指标
        accuracy = accuracy_score(self.y_test, y_pred_binary)
        precision = precision_score(self.y_test, y_pred_binary)
        recall = recall_score(self.y_test, y_pred_binary)
        f1 = f1_score(self.y_test, y_pred_binary)
        auc = roc_auc_score(self.y_test, y_pred)
        
        # 记录评估结果
        self.logger.info(f"测试集评估结果:")
        self.logger.info(f"准确率: {accuracy:.4f}")
        self.logger.info(f"精确率: {precision:.4f}")
        self.logger.info(f"召回率: {recall:.4f}")
        self.logger.info(f"F1分数: {f1:.4f}")
        self.logger.info(f"AUC: {auc:.4f}")
        
        # 保存评估结果到txt文件
        results = {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'f1': f1,
            'auc': auc
        }
        
        # 保存评估结果到txt文件
        with open(os.path.join(self.output_dir, 'evaluation_results.txt'), 'w', encoding='utf-8') as f:
            f.write("模型评估结果\n")
            f.write("=" * 50 + "\n")
            f.write(f"准确率: {accuracy:.4f}\n")
            f.write(f"精确率: {precision:.4f}\n")
            f.write(f"召回率: {recall:.4f}\n")
            f.write(f"F1分数: {f1:.4f}\n")
            f.write(f"AUC: {auc:.4f}\n")
        
        # 绘制混淆矩阵
        cm = confusion_matrix(self.y_test, y_pred_binary)
        plt.figure(figsize=(8, 6))
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
        plt.title('混淆矩阵')
        plt.ylabel('真实标签')
        plt.xlabel('预测标签')
        plt.savefig(os.path.join(self.output_dir, 'confusion_matrix.png'))
        plt.close()
        
        # 绘制ROC曲线
        fpr, tpr, _ = roc_curve(self.y_test, y_pred)
        plt.figure(figsize=(8, 6))
        plt.plot(fpr, tpr, color='darkorange', lw=2, 
                 label=f'ROC curve (AUC = {auc:.2f})')
        plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('ROC曲线')
        plt.legend(loc="lower right")
        plt.savefig(os.path.join(self.output_dir, 'roc_curve.png'))
        plt.close()
        
        return results
    
    def save_model(self):
        """保存模型和相关信息"""
        self.logger.info("开始保存模型...")
        
        # 保存模型
        model_path = os.path.join(self.output_dir, 'dga_detector.json')
        self.model.save_model(model_path)
        
        # 保存特征重要性
        importance = self.model.get_score(importance_type='gain')
        importance_df = pd.DataFrame({
            'feature': list(importance.keys()),
            'importance': list(importance.values())
        }).sort_values('importance', ascending=False)
        
        importance_df.to_csv(os.path.join(self.output_dir, 'feature_importance.csv'), index=False)
        
        # 绘制特征重要性图
        plt.figure(figsize=(15, 8))
        sns.barplot(x='importance', y='feature', 
                   data=importance_df.head(30))
        plt.title('Top 30 特征重要性')
        plt.tight_layout()
        plt.savefig(os.path.join(self.output_dir, 'feature_importance.png'))
        plt.close()
        
        # 保存模型参数
        with open(os.path.join(self.output_dir, 'model_params.txt'), 'w') as f:
            for key, value in self.params.items():
                f.write(f"{key}: {value}\n")
        
        self.logger.info("模型保存完成")
    
    def run(self):
        """运行完整的训练流程"""
        try:
            self.load_data()
            self.train_model()
            results = self.evaluate_model()
            self.save_model()
            return results
        except Exception as e:
            self.logger.error(f"训练过程出错: {str(e)}")
            raise

def main():
    # 创建训练器实例
    trainer = XGBoostTrainer()
    
    # 运行训练流程
    results = trainer.run()
    
    print("\n训练完成！模型和评估结果已保存到", trainer.output_dir)
    print("\n测试集评估结果:")
    print(f"准确率: {results['accuracy']:.4f}")
    print(f"精确率: {results['precision']:.4f}")
    print(f"召回率: {results['recall']:.4f}")
    print(f"F1分数: {results['f1']:.4f}")
    print(f"AUC: {results['auc']:.4f}")

if __name__ == "__main__":
    main() 