import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
import os
from scipy import stats
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE

# 设置matplotlib样式
plt.style.use('default')  # 使用默认样式
plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号
plt.rcParams['figure.figsize'] = [10, 6]  # 设置默认图形大小
plt.rcParams['figure.dpi'] = 100  # 设置默认DPI

class FeatureAnalysis:
    def __init__(self, output_dir='output/feature_analysis'):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)
        
    def plot_class_distribution(self, df):
        """绘制类别分布饼图"""
        plt.figure(figsize=(10, 6))
        class_counts = df['class'].value_counts()
        plt.pie(class_counts, labels=['正常域名', 'DGA域名'], autopct='%1.1f%%', colors=['lightblue', 'lightcoral'])
        plt.title('域名类别分布')
        plt.savefig(os.path.join(self.output_dir, 'class_distribution.png'))
        plt.close()
        
    def plot_feature_distribution(self, df, feature_name):
        """绘制特征分布对比图"""
        plt.figure(figsize=(10, 6))
        
        # 分别绘制DGA和正常域名的分布
        sns.kdeplot(data=df[df['class'] == 1][feature_name], label='DGA域名', fill=True)
        sns.kdeplot(data=df[df['class'] == 0][feature_name], label='正常域名', fill=True)
        
        plt.title(f'{feature_name}特征分布对比')
        plt.xlabel(feature_name)
        plt.ylabel('密度')
        plt.legend()
        
        plt.savefig(os.path.join(self.output_dir, f'{feature_name}_distribution.png'))
        plt.close()
        
    def plot_correlation_heatmap(self, df, top_n=20):
        """绘制特征相关性热力图"""
        # 选择数值型特征
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col not in ['class', 'label']]
        
        # 计算相关性
        corr_matrix = df[numeric_cols].corr()
        
        # 选择相关性最强的top_n个特征
        corr_abs = corr_matrix.abs()
        top_features = corr_abs.sum().nlargest(top_n).index
        corr_matrix = corr_matrix.loc[top_features, top_features]
        
        plt.figure(figsize=(15, 12))
        sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', center=0, fmt='.2f')
        plt.title('特征相关性热力图')
        plt.xticks(rotation=45, ha='right')
        plt.yticks(rotation=0)
        plt.tight_layout()
        
        plt.savefig(os.path.join(self.output_dir, 'correlation_heatmap.png'))
        plt.close()
        
    def plot_feature_importance(self, df, top_n=20):
        """绘制特征重要性条形图"""
        # 准备数据
        X = df.drop(['class', 'label'], axis=1)
        y = df['class']
        
        # 训练随机森林模型
        rf = RandomForestClassifier(n_estimators=100, random_state=42)
        rf.fit(X, y)
        
        # 获取特征重要性
        importance = pd.DataFrame({
            'feature': X.columns,
            'importance': rf.feature_importances_
        })
        importance = importance.sort_values('importance', ascending=False).head(top_n)
        
        plt.figure(figsize=(12, 8))
        sns.barplot(x='importance', y='feature', data=importance)
        plt.title('特征重要性排名')
        plt.xlabel('重要性得分')
        plt.ylabel('特征名称')
        plt.tight_layout()
        
        plt.savefig(os.path.join(self.output_dir, 'feature_importance.png'))
        plt.close()
        
    def plot_pca_visualization(self, df):
        """绘制PCA降维可视化图"""
        # 准备数据
        X = df.drop(['class', 'label'], axis=1)
        y = df['class']
        
        # 标准化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # PCA降维
        pca = PCA(n_components=2)
        X_pca = pca.fit_transform(X_scaled)
        
        # 绘制散点图
        plt.figure(figsize=(10, 8))
        plt.scatter(X_pca[y == 0, 0], X_pca[y == 0, 1], label='正常域名', alpha=0.5)
        plt.scatter(X_pca[y == 1, 0], X_pca[y == 1, 1], label='DGA域名', alpha=0.5)
        plt.title('PCA降维可视化')
        plt.xlabel('第一主成分')
        plt.ylabel('第二主成分')
        plt.legend()
        
        plt.savefig(os.path.join(self.output_dir, 'pca_visualization.png'))
        plt.close()
        
    def plot_tsne_visualization(self, df):
        """绘制t-SNE降维可视化图"""
        # 准备数据
        X = df.drop(['class', 'label'], axis=1)
        y = df['class']
        
        # 标准化
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # t-SNE降维
        tsne = TSNE(n_components=2, random_state=42)
        X_tsne = tsne.fit_transform(X_scaled)
        
        # 绘制散点图
        plt.figure(figsize=(10, 8))
        plt.scatter(X_tsne[y == 0, 0], X_tsne[y == 0, 1], label='正常域名', alpha=0.5)
        plt.scatter(X_tsne[y == 1, 0], X_tsne[y == 1, 1], label='DGA域名', alpha=0.5)
        plt.title('t-SNE降维可视化')
        plt.xlabel('t-SNE维度1')
        plt.ylabel('t-SNE维度2')
        plt.legend()
        
        plt.savefig(os.path.join(self.output_dir, 'tsne_visualization.png'))
        plt.close()
        
    def plot_feature_statistics(self, df):
        """绘制特征统计信息图"""
        # 选择数值型特征
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        numeric_cols = [col for col in numeric_cols if col not in ['class', 'label']]
        
        # 计算每个特征的统计信息
        stats_df = df[numeric_cols].describe()
        
        # 绘制箱线图
        plt.figure(figsize=(15, 8))
        sns.boxplot(data=df[numeric_cols])
        plt.title('特征统计分布')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        plt.savefig(os.path.join(self.output_dir, 'feature_statistics.png'))
        plt.close()
        
    def generate_all_visualizations(self, df):
        """生成所有可视化图表"""
        print("开始生成特征分析可视化图表...")
        
        # 1. 绘制类别分布
        print("生成类别分布图...")
        self.plot_class_distribution(df)
        
        # 2. 生成相关性热力图
        print("生成相关性热力图...")
        self.plot_correlation_heatmap(df)
        
        # 3. 生成特征重要性图
        print("生成特征重要性图...")
        self.plot_feature_importance(df)
        
        # 4. 生成PCA和t-SNE可视化
        print("生成降维可视化图...")
        self.plot_pca_visualization(df)
        self.plot_tsne_visualization(df)
        
        # 5. 生成特征统计信息图
        print("生成特征统计信息图...")
        self.plot_feature_statistics(df)
        
        # 6. 选择重要特征进行详细分析
        important_features = [
            'length', 'entropy', 'num_digits', 'num_letters',
            'num_special_chars', 'vowel_ratio', 'consonant_ratio',
            'max_consecutive_digits', 'max_consecutive_letters'
        ]
        
        for feature in important_features:
            if feature in df.columns:
                print(f"生成{feature}特征的可视化...")
                self.plot_feature_distribution(df, feature)
        
        print("所有可视化图表生成完成！")

def main():
    # 加载合并后的特征数据
    print("加载特征数据...")
    df = pd.read_csv('output/all_features.csv')
    
    # 创建分析对象
    analyzer = FeatureAnalysis()
    
    # 生成所有可视化图表
    analyzer.generate_all_visualizations(df)

if __name__ == "__main__":
    main() 