# DGA域名检测系统

## 项目概述
本项目是一个基于机器学习的DGA（Domain Generation Algorithm）域名检测系统，用于识别恶意域名。项目实现了多种机器学习模型，包括决策树、随机森林、LightGBM、CatBoost和XGBoost等，并提供了完整的特征工程和模型评估流程。

## 环境要求
- Python 3.10+
- 建议使用虚拟环境（如venv或uv）

## 项目结构
```
.
├── data/                  # 数据集
├── model/                 # 模型文件
├── output/               # 输出文件
├── *.py                  # 主要代码文件
└── requirements.txt      # 项目依赖
```

### 安装依赖
```bash
# 使用pip安装
pip install -r requirements.txt

# 或使用uv安装（推荐）
uv pip install -r requirements.txt
```

> **注意事项**：
> - 项目依赖较多，建议根据实际需求选择性安装
> - 部分代码（如feature_analysis.py）会占用较高CPU资源，请谨慎运行
> - 运行过程中会生成大量中间文件，请及时清理不需要的文件
> - 请严格按照文档顺序执行各个步骤

## 数据集
### 数据来源
数据集来自HuggingFace：[harpomaxx/dga-detection](https://huggingface.co/datasets/harpomaxx/dga-detection)

### 数据下载
```bash
python DownLoadDataset.py
```

### 数据集信息
```bash
python checkDataset.py
```

数据集规模：
- 训练集：2,042,947条
- 测试集：583,699条
- 验证集：291,850条

## 项目流程

### 1. 数据理解
```bash
python data_understanding.py
```
- 输出目录：`output/dataunderstanding/`
- 包含训练集、测试集和验证集的数据分析可视化

### 2. 特征工程
```bash
python feature_engineering.py
```
- 输出文件：
  - `output/featur_descriptions.txt`：特征说明文档
  - `output/train_features.csv`：训练特征文件

### 3. 特征合并
```bash
python merge_features_csv.py
```
- 输出文件：`output/all_features.csv`

### 4. 特征分析
```bash
python feature_analysis.py
```
- 输出目录：`output/feature_analysis/`

### 5. 模型训练
```bash
# 决策树模型
python model_training_decision_tree.py

# 随机森林模型
python model_training_rf.py

# LightGBM模型
python model_training_lgb.py

# CatBoost模型
python model_training_catboost.py

# XGBoost模型
python model_training_xgb.py
```

模型输出：
- 模型文件：`model/*.joblib`
- 评估指标：`model/*/model_metrics.csv`
- 可视化结果：`model/*/*.png`
- 训练日志：`model/*/*_log_*.txt`

### 6. 模型比较
```bash
python compare.py
```
- 输出在主目录中
- 输出文件：`score-compa.png`

## 作者信息
- 最后更新：2025/6/3