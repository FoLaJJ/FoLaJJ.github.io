from datasets import load_dataset
import os
import matplotlib.pyplot as plt
import numpy as np

# 设置缓存路径
data_dir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(data_dir, exist_ok=True)
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False
# 加载数据集
try:
    ds = load_dataset(
        "harpomaxx/dga-detection",
        cache_dir=data_dir,
        trust_remote_code=True
    )
    print("数据集加载成功！")

    # 1. 查看所有子集
    print("可用子集:", list(ds.keys()))

    # 2. 分别访问不同子集
    train_set = ds["train"]
    test_set = ds["test"]
    valid_set = ds["validation"]

    # 3. 打印各子集信息
    print(f"\n训练集样本数: {len(train_set)}")
    print(f"测试集样本数: {len(test_set)}")
    print(f"验证集样本数: {len(valid_set)}")

    # 4. 检查字段和样本
    print("\n训练集字段:", train_set.features)
    print("\n测试集前5条数据:")
    print(test_set[:5])

    # 5. 绘制并保存数据集样本数直方图
    output_dir = os.path.join(os.path.dirname(__file__), "output", "dataset")
    os.makedirs(output_dir, exist_ok=True)

    # 准备数据
    subsets = ['训练集', '测试集', '验证集']
    counts = [len(train_set), len(test_set), len(valid_set)]

    # 创建直方图
    plt.figure(figsize=(8, 6))
    bars = plt.bar(subsets, counts, color=['#1f77b4', '#ff7f0e', '#2ca02c'])

    # 添加数值标签
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2., height,
                 f'{int(height)}',
                 ha='center', va='bottom')

    plt.title('数据集样本数量分布', fontsize=14)
    plt.ylabel('样本数量', fontsize=12)
    plt.grid(axis='y', linestyle='--', alpha=0.7)

    # 保存图片
    plot_path = os.path.join(output_dir, 'dataset_distribution.png')
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()

    print(f"\n数据集样本数直方图已保存至: {plot_path}")

except Exception as e:
    print("加载失败:", str(e))