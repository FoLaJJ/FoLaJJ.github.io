# data_understanding.py
from datasets import load_dataset
import pandas as pd
import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud
import os
from scipy import stats

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体显示中文
plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题
mpl.rcParams['font.size'] = 12  # 设置全局字体大小

# 创建输出目录结构
output_dir = os.path.join(os.path.dirname(__file__), "output")
dataunderstanding_dir = os.path.join(output_dir, "dataunderstanding")
for split in ['train', 'validation', 'test']:
    os.makedirs(os.path.join(dataunderstanding_dir, split), exist_ok=True)

data_dir = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(data_dir, exist_ok=True)

# 加载数据集
def load_data():
    """加载DGA检测数据集"""
    print("正在加载数据集...")
    ds = load_dataset(
        "harpomaxx/dga-detection",
        cache_dir=data_dir,
        trust_remote_code=True
    )
    print("数据集加载成功!")
    return ds

# 基础特征分析
def basic_analysis(ds, split_name):
    """执行基础数据分析：数据特征、质量、类别分布"""
    # 使用指定数据集创建DataFrame
    df = pd.DataFrame(ds[split_name])
    output_subdir = os.path.join(dataunderstanding_dir, split_name)

    print(f"\n{'='*50}")
    print(f"{split_name}集数据特征分析")
    print(f"{'='*50}")

    # 1. 数据特征
    print(f"\n总样本数: {len(df):,}")
    print(f"特征字段: {list(df.columns)}")
    print(f"数据类型:\n{df.dtypes}")

    # 2. 数据质量
    print("\n" + "-"*20 + " 数据质量 " + "-"*20)
    print(f"缺失值统计:\n{df.isnull().sum()}")
    duplicate_count = df.duplicated().sum()
    print(f"重复值数量: {duplicate_count:,} ({duplicate_count/len(df)*100:.2f}%)")

    # 3. 类别分布
    print("\n" + "-"*20 + " 类别分布 " + "-"*20)
    class_dist = df['class'].value_counts(normalize=True)
    print(f"类别比例 (0=正常, 1=DGA):\n{class_dist}")

    label_dist = df['label'].value_counts()
    print(f"\n详细标签分布 (前10):\n{label_dist.head(10)}")

    # 4. 标签映射验证
    print("\n" + "-"*20 + " 标签映射验证 " + "-"*20)
    label_class_map = df.groupby('label')['class'].unique()
    inconsistent_labels = label_class_map[label_class_map.apply(len) > 1]

    if not inconsistent_labels.empty:
        print("警告: 发现不一致的标签-类别映射:")
        print(inconsistent_labels)
    else:
        print("所有标签都有唯一的类别映射")

    # 5. 详细类别分析
    print("\n" + "-"*20 + " 详细类别分析 " + "-"*20)
    class_0_labels = df[df['class'] == 0]['label'].unique()
    class_1_labels = df[df['class'] == 1]['label'].unique()

    print(f"正常域名标签数: {len(class_0_labels)}")
    print(f"DGA域名标签数: {len(class_1_labels)}")
    print(f"正常域名主要来源: {class_0_labels[0] if len(class_0_labels) > 0 else '无'}")
    print(f"DGA域名主要家族: {', '.join(class_1_labels[:5])}")

    # 6. 添加样本量警告
    class_counts = df['class'].value_counts()
    min_class_count = min(class_counts)
    if min_class_count < 1000:
        print(f"\n警告：最小类别样本量较低 ({min_class_count})，可能影响后续分析")

    return df, output_subdir

# 域名特征工程
def extract_features(df):
    """从域名中提取关键特征"""
    print("\n" + "="*50)
    print("域名特征提取")
    print("="*50)

    # 提取基础特征
    df['domain_length'] = df['domain'].apply(len)
    df['digit_count'] = df['domain'].apply(lambda x: sum(c.isdigit() for c in x))
    df['hyphen_count'] = df['domain'].apply(lambda x: x.count('-'))
    df['tld'] = df['domain'].apply(lambda x: x.split('.')[-1])

    # 计算数字比例
    df['digit_ratio'] = df['digit_count'] / df['domain_length']

    print("\n提取的特征:")
    print(df[['domain', 'domain_length', 'digit_count', 'hyphen_count', 'tld']].head())

    return df

# 可视化分析
def visualize_data(df, output_subdir):
    """创建数据可视化图表"""
    print("\n" + "="*50)
    print("创建可视化图表")
    print("="*50)

    # === 1. 基础分布图 ===

    # 1.1 类别分布图
    plt.figure(figsize=(8, 6))
    sns.countplot(x='class', data=df)
    plt.title('域名类别分布')
    plt.xlabel('类别 (0=正常, 1=DGA)')
    plt.ylabel('数量')
    plt.savefig(os.path.join(output_subdir, 'class_distribution.png'))
    plt.close()

    # 计算各类别样本量
    class_counts = df['class'].value_counts()
    min_class_count = min(class_counts)

    # 检查最小样本量是否足够
    if min_class_count < 100:
        print(f"警告：最小类别样本量不足 ({min_class_count})，部分可视化可能受限")

    # 动态设置抽样大小
    sample_size_per_class = min(5000, min_class_count)  # 确保不超过最小类别样本量

    if sample_size_per_class < 100:
        print("警告：样本量过少，跳过后续可视化")
        return

    # 抽样避免内存问题
    class_0_sample = df[df['class'] == 0].sample(
        n=sample_size_per_class,
        random_state=42,
        replace=False  # 无放回抽样
    )
    class_1_sample = df[df['class'] == 1].sample(
        n=sample_size_per_class,
        random_state=42,
        replace=False
    )
    sample_df = pd.concat([class_0_sample, class_1_sample])

    # 1.2 域名长度分布
    plt.figure(figsize=(10, 6))
    sns.kdeplot(data=class_0_sample, x='domain_length',
                label='正常域名', fill=True, alpha=0.5, color='blue')
    sns.kdeplot(data=class_1_sample, x='domain_length',
                label='DGA域名', fill=True, alpha=0.5, color='red')

    # 添加统计标注
    mean_0 = class_0_sample['domain_length'].mean()
    mean_1 = class_1_sample['domain_length'].mean()
    plt.axvline(mean_0, color='blue', linestyle='--', alpha=0.7)
    plt.axvline(mean_1, color='red', linestyle='--', alpha=0.7)
    plt.text(mean_0, plt.ylim()[1] * 0.9, f'正常均值: {mean_0:.1f}', color='blue')
    plt.text(mean_1, plt.ylim()[1] * 0.85, f'DGA均值: {mean_1:.1f}', color='red')

    plt.title('域名长度分布对比')
    plt.xlabel('域名长度')
    plt.ylabel('密度')
    plt.legend()
    plt.savefig(os.path.join(output_subdir, 'domain_length_distribution.png'))
    plt.close()

    # 1.3 数字比例分布
    plt.figure(figsize=(10, 6))
    sns.boxplot(x='class', y='digit_ratio', data=sample_df)
    plt.title('域名数字比例分布')
    plt.xlabel('类别 (0=正常, 1=DGA)')
    plt.ylabel('数字比例')

    # 添加解释文本
    median_0 = class_0_sample['digit_ratio'].median()
    median_1 = class_1_sample['digit_ratio'].median()
    plt.text(0.5, 0.9, f'正常域名数字比例中位数: {median_0:.3f}\nDGA域名数字比例中位数: {median_1:.3f}',
             transform=plt.gca().transAxes, ha='center', bbox=dict(facecolor='white', alpha=0.8))
    plt.savefig(os.path.join(output_subdir, 'digit_ratio_distribution.png'))
    plt.close()

    # 1.4 连字符分布
    plt.figure(figsize=(10, 6))
    sns.kdeplot(data=class_0_sample, x='hyphen_count',
                label='正常域名', fill=True, alpha=0.5, color='blue')
    sns.kdeplot(data=class_1_sample, x='hyphen_count',
                label='DGA域名', fill=True, alpha=0.5, color='red')

    # 添加统计标注
    mean_0 = class_0_sample['hyphen_count'].mean()
    mean_1 = class_1_sample['hyphen_count'].mean()
    plt.axvline(mean_0, color='blue', linestyle='--', alpha=0.7)
    plt.axvline(mean_1, color='red', linestyle='--', alpha=0.7)
    plt.text(mean_0, plt.ylim()[1] * 0.9, f'正常均值: {mean_0:.2f}', color='blue')
    plt.text(mean_1, plt.ylim()[1] * 0.85, f'DGA均值: {mean_1:.2f}', color='red')

    plt.title('连字符使用分布对比')
    plt.xlabel('连字符数量')
    plt.ylabel('密度')
    plt.legend()
    plt.savefig(os.path.join(output_subdir, 'hyphen_distribution.png'))
    plt.close()

    # === 2. 特征分析图 ===

    # 2.1 特征相关性图
    plt.figure(figsize=(10, 8))
    corr_matrix = df[['domain_length', 'digit_count', 'hyphen_count', 'class']].corr()
    sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
    plt.title('特征相关性矩阵')
    plt.savefig(os.path.join(output_subdir, 'feature_correlation.png'))
    plt.close()

    # 2.2 数字特征分布
    plt.figure(figsize=(10, 6))
    sns.kdeplot(data=class_0_sample, x='digit_count',
                label='正常域名', fill=True, alpha=0.5, color='blue')
    sns.kdeplot(data=class_1_sample, x='digit_count',
                label='DGA域名', fill=True, alpha=0.5, color='red')

    # 添加统计标注
    mean_0 = class_0_sample['digit_count'].mean()
    mean_1 = class_1_sample['digit_count'].mean()
    plt.axvline(mean_0, color='blue', linestyle='--', alpha=0.7)
    plt.axvline(mean_1, color='red', linestyle='--', alpha=0.7)
    plt.text(mean_0, plt.ylim()[1] * 0.9, f'正常均值: {mean_0:.2f}', color='blue')
    plt.text(mean_1, plt.ylim()[1] * 0.85, f'DGA均值: {mean_1:.2f}', color='red')

    plt.title('域名数字数量分布对比')
    plt.xlabel('数字数量')
    plt.ylabel('密度')
    plt.legend()
    plt.savefig(os.path.join(output_subdir, 'digit_count_distribution.png'))
    plt.close()

    # === 3. 深度分析图 ===

    # 3.1 TLD分布对比
    plt.figure(figsize=(14, 8))

    # 正常域名TLD分布
    plt.subplot(1, 2, 1)
    normal_tlds = df[df['class'] == 0]['tld'].value_counts().head(10)
    sns.barplot(x=normal_tlds.values, y=normal_tlds.index,
                hue=normal_tlds.index, palette='Blues_d', dodge=False, legend=False)
    plt.title('正常域名Top 10 TLD')
    plt.xlabel('数量')
    plt.ylabel('顶级域名')

    # DGA域名TLD分布
    plt.subplot(1, 2, 2)
    dga_tlds = df[df['class'] == 1]['tld'].value_counts().head(10)
    sns.barplot(x=dga_tlds.values, y=dga_tlds.index,
                hue=dga_tlds.index, palette='Reds_d', dodge=False, legend=False)
    plt.title('DGA域名Top 10 TLD')
    plt.xlabel('数量')
    plt.ylabel('')

    plt.tight_layout()
    plt.savefig(os.path.join(output_subdir, 'tld_comparison.png'))
    plt.close()

    # 3.2 TLD深度分析
    plt.figure(figsize=(14, 10))

    # 获取Top 15 TLD
    top_tlds = df['tld'].value_counts().head(15).index
    tld_df = df[df['tld'].isin(top_tlds)]

    # 1. TLD使用频率热力图
    plt.subplot(2, 1, 1)
    tld_cross = pd.crosstab(tld_df['tld'], tld_df['class'])
    tld_cross['total'] = tld_cross.sum(axis=1)
    tld_cross = tld_cross.sort_values('total', ascending=False).head(15)
    tld_cross.drop('total', axis=1, inplace=True)

    sns.heatmap(tld_cross, annot=True, fmt='d', cmap='YlGnBu')
    plt.title('Top 15 TLD分布热力图')
    plt.ylabel('顶级域名')
    plt.xlabel('类别 (0=正常, 1=DGA)')

    # 2. TLD比例分析
    plt.subplot(2, 1, 2)
    tld_cross['dga_ratio'] = tld_cross[1] / (tld_cross[0] + tld_cross[1])
    sns.barplot(x=tld_cross.index, y='dga_ratio', data=tld_cross,
                hue=tld_cross.index, palette='Reds_r', legend=False)

    plt.title('各TLD中DGA域名比例')
    plt.xlabel('顶级域名')
    plt.ylabel('DGA比例')
    plt.xticks(rotation=45)
    plt.ylim(0, 1)

    plt.tight_layout()
    plt.savefig(os.path.join(output_subdir, 'tld_analysis.png'))
    plt.close()

    # 3.3 域名词云
    if len(class_0_sample) >= 100 and len(class_1_sample) >= 100:
        plt.figure(figsize=(16, 8))

        # 正常域名词云
        plt.subplot(1, 2, 1)
        normal_sample = " ".join(class_0_sample['domain'].sample(min(500, len(class_0_sample))))
        wordcloud = WordCloud(width=800, height=500,
                            background_color='white',
                            max_words=200).generate(normal_sample)
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title('正常域名词云')

        # DGA域名词云
        plt.subplot(1, 2, 2)
        dga_sample = " ".join(class_1_sample['domain'].sample(min(500, len(class_1_sample))))
        wordcloud = WordCloud(width=800, height=500,
                            background_color='white',
                            max_words=200).generate(dga_sample)
        plt.imshow(wordcloud, interpolation='bilinear')
        plt.axis('off')
        plt.title('DGA域名词云')

        plt.tight_layout()
        plt.savefig(os.path.join(output_subdir, 'domain_wordclouds.png'))
        plt.close()
        print(f"域名词云图已保存到 {os.path.join(output_subdir, 'domain_wordclouds.png')}")
    else:
        print("样本量不足，跳过域名词云生成")

    print(f"所有图表已保存到 {output_subdir} 目录")

# 高级统计分析
def advanced_analysis(df, output_subdir):
    """执行高级统计分析"""
    print("\n" + "="*50)
    print("高级统计分析")
    print("="*50)

    # 按类别分组
    class_0 = df[df['class'] == 0]  # 正常域名
    class_1 = df[df['class'] == 1]  # DGA域名

    # 检查样本量是否足够
    if len(class_0) < 10 or len(class_1) < 10:
        print("警告：某个类别的样本量过少，跳过高级分析")
        return

    # 域名长度分析
    print("\n" + "-"*20 + " 域名长度分析 " + "-"*20)
    print(f"正常域名平均长度: {class_0['domain_length'].mean():.2f} ± {class_0['domain_length'].std():.2f}")
    print(f"DGA域名平均长度: {class_1['domain_length'].mean():.2f} ± {class_1['domain_length'].std():.2f}")
    print(f"长度差异倍数: {class_1['domain_length'].mean() / class_0['domain_length'].mean():.2f}x")

    # 数字使用分析
    print("\n" + "-"*20 + " 数字使用分析 " + "-"*20)
    print(f"正常域名平均数字数量: {class_0['digit_count'].mean():.2f} ± {class_0['digit_count'].std():.2f}")
    print(f"DGA域名平均数字数量: {class_1['digit_count'].mean():.2f} ± {class_1['digit_count'].std():.2f}")
    print(f"数字使用差异倍数: {class_1['digit_count'].mean() / class_0['digit_count'].mean():.2f}x")

    print(f"\n正常域名数字比例: {class_0['digit_ratio'].mean():.4f} ± {class_0['digit_ratio'].std():.4f}")
    print(f"DGA域名数字比例: {class_1['digit_ratio'].mean():.4f} ± {class_1['digit_ratio'].std():.4f}")
    print(f"数字比例差异倍数: {class_1['digit_ratio'].mean() / class_0['digit_ratio'].mean():.2f}x")

    # 连字符使用分析
    print("\n" + "-"*20 + " 连字符使用分析 " + "-"*20)
    print(f"正常域名平均连字符数量: {class_0['hyphen_count'].mean():.2f} ± {class_0['hyphen_count'].std():.2f}")
    print(f"DGA域名平均连字符数量: {class_1['hyphen_count'].mean():.2f} ± {class_1['hyphen_count'].std():.2f}")
    print(f"连字符使用差异: {'正常域名使用更多' if class_0['hyphen_count'].mean() > class_1['hyphen_count'].mean() else 'DGA域名使用更多'}")

    # 统计显著性检验
    print("\n" + "-"*20 + " 统计显著性检验 " + "-"*20)
    sample_size = min(10000, len(class_0), len(class_1))
    for feature in ['domain_length', 'digit_count', 'hyphen_count']:
        # 确保抽样大小不超过样本量
        sample_0 = class_0[feature].sample(n=min(sample_size, len(class_0)), random_state=42)
        sample_1 = class_1[feature].sample(n=min(sample_size, len(class_1)), random_state=42)

        t_stat, p_val = stats.ttest_ind(sample_0, sample_1, equal_var=False)
        significance = "显著差异" if p_val < 0.05 else "无显著差异"
        print(f"{feature}: p值 = {p_val:.4f} ({significance})")

    # TLD分析
    print("\n" + "-"*20 + " 顶级域名分析 " + "-"*20)
    normal_tlds = class_0['tld'].value_counts().head(5)
    dga_tlds = class_1['tld'].value_counts().head(5)

    print("正常域名Top 5 TLD:")
    print(normal_tlds)

    print("\nDGA域名Top 5 TLD:")
    print(dga_tlds)

    common_tlds = set(normal_tlds.index) & set(dga_tlds.index)
    unique_normal_tlds = set(normal_tlds.index) - common_tlds
    unique_dga_tlds = set(dga_tlds.index) - common_tlds

    print(f"\n共同使用的Top TLD: {', '.join(common_tlds)}")
    print(f"正常域名特有的Top TLD: {', '.join(unique_normal_tlds)}")
    print(f"DGA域名特有的Top TLD: {', '.join(unique_dga_tlds)}")

# 主函数
if __name__ == "__main__":
    # 加载数据
    dataset = load_data()

    # 处理每个数据集
    for split_name in ['train', 'validation', 'test']:
        print(f"\n处理{split_name}集...")
        
        # 基础分析
        df, output_subdir = basic_analysis(dataset, split_name)

        # 特征提取
        df = extract_features(df)

        # 可视化分析
        visualize_data(df, output_subdir)

        # 高级分析
        advanced_analysis(df, output_subdir)

        print(f"\n{split_name}集分析完成! 所有图表已保存到 {output_subdir} 目录")

    print("\n所有数据集分析完成!")